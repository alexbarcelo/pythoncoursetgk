from django.apps import AppConfig


class BenvingudaConfig(AppConfig):
    name = 'benvinguda'
